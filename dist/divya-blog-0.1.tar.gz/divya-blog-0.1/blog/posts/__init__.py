class Post:
    def __init__(self, title, author, text):
        self.title = title
        self.author = author
        self.text = text
